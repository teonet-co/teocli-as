var classas_i_binary_stream =
[
    [ "Read", "classas_i_binary_stream.html#ab69b772db0a4157a842d90070e6fa1dc", null ],
    [ "Write", "classas_i_binary_stream.html#a1fce5bbea004d6b2705f9eefae1a3770", null ]
];