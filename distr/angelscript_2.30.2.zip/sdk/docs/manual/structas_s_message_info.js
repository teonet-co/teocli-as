var structas_s_message_info =
[
    [ "col", "structas_s_message_info.html#a08b23a360ac52110323bbf4aad553d9d", null ],
    [ "message", "structas_s_message_info.html#af76694c6342dd82ef6aca0dff42072f5", null ],
    [ "row", "structas_s_message_info.html#a21ef80321436f229a547411a6598ea21", null ],
    [ "section", "structas_s_message_info.html#aeca6368be12c84b62ed8c659b1e4615c", null ],
    [ "type", "structas_s_message_info.html#a6aa9231534b8aea2a3099cdc3206bcc8", null ]
];