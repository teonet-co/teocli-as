var searchData=
[
  ['byte_20code_20instructions',['Byte code instructions',['../doc_adv_jit_1.html',1,'doc_adv_jit_topic']]],
  ['built_2din_20types',['Built-in types',['../doc_builtin_types.html',1,'doc_datatypes']]]
];
