var classas_i_binary_stream =
[
    [ "Read", "classas_i_binary_stream.html#a8bbd68cea1f96b42c723f9732ac19140", null ],
    [ "Write", "classas_i_binary_stream.html#a57724f9cd63a625a843bf97e7704d9a7", null ]
];