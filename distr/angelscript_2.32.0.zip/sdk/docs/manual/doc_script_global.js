var doc_script_global =
[
    [ "Functions", "doc_global_func.html", null ],
    [ "Variables", "doc_global_variable.html", null ],
    [ "Virtual properties", "doc_global_virtprop.html", null ],
    [ "Script classes", "doc_global_class.html", null ],
    [ "Interfaces", "doc_global_interface.html", null ],
    [ "Mixin class", "doc_script_mixin.html", null ],
    [ "Enums", "doc_global_enums.html", null ],
    [ "Funcdefs", "doc_global_funcdef.html", null ],
    [ "Typedefs", "doc_global_typedef.html", null ],
    [ "Namespaces", "doc_global_namespace.html", null ],
    [ "Imports", "doc_global_import.html", null ]
];