var classas_i_string_factory =
[
    [ "GetRawStringData", "classas_i_string_factory.html#ae798179f4d90b30371416f8c5c522333", null ],
    [ "GetStringConstant", "classas_i_string_factory.html#a59d5d4d13a21105791e34bef5cb57e6b", null ],
    [ "ReleaseStringConstant", "classas_i_string_factory.html#ae4ca9e666eb711671a765dba8debe8b1", null ]
];