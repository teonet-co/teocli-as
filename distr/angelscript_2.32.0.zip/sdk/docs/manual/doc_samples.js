var doc_samples =
[
    [ "Tutorial", "doc_samples_tutorial.html", null ],
    [ "Concurrent scripts", "doc_samples_concurrent.html", null ],
    [ "Console", "doc_samples_console.html", null ],
    [ "Co-routines", "doc_samples_corout.html", null ],
    [ "Events", "doc_samples_events.html", null ],
    [ "Include directive", "doc_samples_incl.html", null ],
    [ "Generic compiler", "doc_samples_asbuild.html", null ],
    [ "Commandline runner", "doc_samples_asrun.html", [
      [ "Global functions available to scripts", "doc_samples_asrun.html#doc_samples_asrun_funcs", null ]
    ] ],
    [ "Game", "doc_samples_game.html", null ]
];